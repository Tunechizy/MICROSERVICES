const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Assuming you have a User model defined
const config = require('config'); // For accessing environment variables
const redis = require('redis'); // Assuming Redis is being used to manage refresh tokens
const client = redis.createClient(); // Set up Redis client (adjust connection details as needed)

// Register user
const registerUser = async (req, res) => {
    const { username, email, password, role } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ error: 'Username, email, and password are required' });
    }

    // Check if the user already exists
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
        return res.status(400).json({ error: 'User with this username or email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
        username,
        email,
        password: hashedPassword,
        role: role || 'buyer' // Default to 'buyer' if no role provided
    });

    try {
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Generate JWT and Refresh Token
const generateTokens = (user) => {
    const payload = { userId: user._id, role: user.role };

    // Access Token (JWT)
    const token = jwt.sign(payload, config.get('jwtSecret'), { expiresIn: '1h' });

    // Refresh Token (valid for 7 days)
    const refreshToken = jwt.sign(payload, config.get('jwtSecret'), { expiresIn: '7d' });

    return { token, refreshToken };
};

// Login user
const loginUser = async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }

    const user = await User.findOne({ $or: [{ username }, { email: username }] });
    if (!user) return res.status(400).json({ error: 'User not found' });

    // Check if password matches
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Invalid password' });

    // Generate tokens (JWT and Refresh Token)
    const { token, refreshToken } = generateTokens(user);

    // Store refresh token in Redis (optional, for better session management)
    client.set(user._id.toString(), refreshToken, 'EX', 60 * 60 * 24 * 7, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Error storing refresh token' });
        }
    });

    res.json({ token, refreshToken });
};

// Refresh Token (Re-authenticate)
const refreshAuthToken = async (req, res) => {
    const { refreshToken } = req.body;

    if (!refreshToken) {
        return res.status(400).json({ error: 'Refresh token is required' });
    }

    // Verify the refresh token
    try {
        const decoded = jwt.verify(refreshToken, config.get('jwtSecret'));
        const user = await User.findById(decoded.userId);
        if (!user) {
            return res.status(400).json({ error: 'Invalid refresh token' });
        }

        // Generate a new JWT and refresh token
        const { token, refreshToken: newRefreshToken } = generateTokens(user);

        // Update the refresh token in Redis (optional)
        client.set(user._id.toString(), newRefreshToken, 'EX', 60 * 60 * 24 * 7, (err) => {
            if (err) {
                return res.status(500).json({ error: 'Error storing refresh token' });
            }
        });

        res.json({ token, refreshToken: newRefreshToken });
    } catch (error) {
        return res.status(400).json({ error: 'Invalid or expired refresh token' });
    }
};

// Logout user (optional)
const logoutUser = async (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    // Delete the refresh token from Redis (optional)
    client.del(userId.toString(), (err) => {
        if (err) {
            return res.status(500).json({ error: 'Error logging out user' });
        }
        res.status(200).json({ message: 'User logged out successfully' });
    });
};

// Basic test route (Auth route check)
const getAuth = (req, res) => {
    res.send('Auth route is working!');
};

module.exports = { registerUser, loginUser, refreshAuthToken, logoutUser, getAuth };
