const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // For hashing passwords
const jwt = require('jsonwebtoken'); // For generating JWT
const config = require('config'); // For accessing environment variables (e.g., JWT secret)

// Define the user schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: {
        type: String,
        enum: ['buyer', 'seller'], // Enforcing role-based access (buyer or seller)
        default: 'buyer'
    },
    refreshToken: { type: String } // Optional: Store refresh token for later use
});

// Hash the password before saving to database
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) {
        return next();
    }

    // Hash the password with a salt round of 10
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

// Method to validate password for login
userSchema.methods.isValidPassword = async function (password) {
    return bcrypt.compare(password, this.password);
};

// Method to generate JWT
userSchema.methods.generateAuthToken = function () {
    const payload = { userId: this._id, role: this.role };

    // Generate JWT with expiration time (e.g., 1 hour)
    const token = jwt.sign(payload, config.get('jwtSecret'), { expiresIn: '1h' });
    return token;
};

// Method to generate refresh token (Optional)
userSchema.methods.generateRefreshToken = function () {
    const payload = { userId: this._id, role: this.role };

    // Generate a refresh token without expiration (refresh token managed separately)
    const refreshToken = jwt.sign(payload, config.get('jwtSecret'), { expiresIn: '7d' });
    return refreshToken;
};

// Static method to find user by username or email (useful for login)
userSchema.statics.findByCredentials = async function (usernameOrEmail, password) {
    const user = await this.findOne({ $or: [{ username: usernameOrEmail }, { email: usernameOrEmail }] });
    if (!user) {
        throw new Error('Invalid username or email');
    }

    const isPasswordMatch = await user.isValidPassword(password);
    if (!isPasswordMatch) {
        throw new Error('Invalid password');
    }

    return user;
};

// Export the model
module.exports = mongoose.model('User', userSchema);
