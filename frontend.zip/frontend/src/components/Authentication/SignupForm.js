import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import for navigation
import axios from 'axios'; // Import for making HTTP requests
import './Auth.css'; // Import for styling

const Signup = () => {
  // State hooks for managing form data and error messages
  const [formInputs, setFormInputs] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    termsAccepted: false,
  });

  const [errorMsg, setErrorMsg] = useState(''); // State for capturing error messages
  const navigate = useNavigate(); // Navigation hook for routing to different pages

  // Handle changes to form inputs
  const updateInput = (event) => {
    const { name, value, type, checked } = event.target;
    setFormInputs({
      ...formInputs,
      [name]: type === 'checkbox' ? checked : value, // Handle checkbox vs text inputs
    });
  };

  // Handle form submission
  const onFormSubmit = async (event) => {
    event.preventDefault(); // Prevent the form from refreshing the page

    // Validate passwords match
    if (formInputs.password !== formInputs.confirmPassword) {
      alert('Password mismatch! Please try again.');
      return;
    }

    // Ensure terms and conditions are accepted
    if (!formInputs.termsAccepted) {
      alert('Please agree to the Terms and Conditions.');
      return;
    }

    try {
      // Send POST request using axios to backend API
      const response = await axios.post('http://localhost:5000/auth/signup', {
        username: formInputs.username,
        email: formInputs.email,
        password: formInputs.password,
      });

      console.log('User signed up:', response.data); // Log success response

      // After successful signup, navigate to login page
      navigate('/login');
    } catch (error) {
      console.error('Error during signup:', error); // Log error

      // Display appropriate error message based on response
      if (error.response) {
        setErrorMsg(error.response.data.error || 'Signup failed. Try again later.');
      } else if (error.request) {
        setErrorMsg('Server did not respond. Please try again later.');
      } else {
        setErrorMsg('An error occurred. Please try again.');
      }
    }
  };

  return (
    <div className="auth-container">
      <h2>Register New Account</h2>
      <form className="auth-form" onSubmit={onFormSubmit}>
        {/* Input fields for username, email, password, and confirm password */}
        <input
          type="text"
          name="username"
          placeholder="Choose a Username"
          value={formInputs.username}
          onChange={updateInput}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Enter Your Email"
          value={formInputs.email}
          onChange={updateInput}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Set a Password"
          value={formInputs.password}
          onChange={updateInput}
          required
        />
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formInputs.confirmPassword}
          onChange={updateInput}
          required
        />
        <div>
          <input
            type="checkbox"
            name="termsAccepted"
            checked={formInputs.termsAccepted}
            onChange={updateInput}
            required
          />
          <label>I agree to the Terms and Conditions</label>
        </div>
        <button type="submit">Sign Up</button>
      </form>
      {errorMsg && <p className="error">{errorMsg}</p>} {/* Display error message if any */}
      <p>
        Already have an account?{' '}
        <span className="link" onClick={() => navigate('/login')}>
          Login
        </span>
      </p>
    </div>
  );
};

export default Signup;
