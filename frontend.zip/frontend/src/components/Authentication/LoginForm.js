import React, { useState } from "react"; // Importing React and the useState hook for managing state
import { useNavigate } from "react-router-dom"; // Importing useNavigate hook to handle route navigation
import "./Auth.css"; // Importing CSS file for styling the form

// SignupForm component
const SignupForm = ({ setUser }) => {
  // Initializing state for form data (email, password) and error messages
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState(""); // State to hold error message
  const navigate = useNavigate(); // Hook to navigate to different routes

  // Function to handle input changes and update the form data state
  const handleInputChange = (e) => {
    const { name, value } = e.target; // Destructure the name and value from the event target
    setFormData({ ...formData, [name]: value }); // Update the specific field in formData
  };

  // Function to handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevents the default form submission behavior
    setError(""); // Reset the error message on each submission

    try {
      // Sending a POST request to the backend to create a new user
      const response = await fetch("http://localhost:5000/auth/signup", {
        method: "POST", // Using POST method for signup
        headers: {
          "Content-Type": "application/json", // Sending JSON data
        },
        body: JSON.stringify(formData), // Convert form data to JSON for the request body
      });

      // Handling the response from the backend
      if (response.ok) { // If the response is successful (status 2xx)
        const data = await response.json(); // Parse the response as JSON
        // Store the authentication token and user email in localStorage
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("userEmail", formData.email);
        setUser({ email: formData.email }); // Update the user state with the email
        console.log('Signup Successful:', data); // Log the success message
        navigate("/home"); // Navigate to the home page after successful signup
      } else {
        // Handle any error responses from the server (e.g., user already exists)
        const errorData = await response.json();
        setError(errorData.error || "Signup failed. Please try again."); // Display error message
      }
    } catch (err) {
      // Catch any unexpected errors during the fetch request
      console.error("Error during signup:", err);
      setError("An error occurred. Please try again later."); // Display generic error message
    }
  };

  return (
    <div className="auth-container"> {/* Container for the entire form */}
      <h2>Sign Up</h2> {/* Title of the form */}
      <form className="auth-form" onSubmit={handleSubmit}> {/* Form element with onSubmit handler */}
        <input
          type="email" // Input field for email
          name="email" // Name of the input field (used for state update)
          placeholder="Email" // Placeholder text for the email field
          value={formData.email} // Controlled input value linked to state
          onChange={handleInputChange} // Call handleInputChange on any input change
          required // Ensure the field is filled before submitting
        />
        <input
          type="password" // Input field for password
          name="password" // Name of the input field (used for state update)
          placeholder="Password" // Placeholder text for the password field
          value={formData.password} // Controlled input value linked to state
          onChange={handleInputChange} // Call handleInputChange on any input change
          required // Ensure the field is filled before submitting
        />
        <button type="submit">Sign Up</button> {/* Submit button for the form */}
      </form>
      {error && <p className="error">{error}</p>} {/* Display the error message if there's any */}
      <p>
        Already have an account?{" "}
        <span className="link" onClick={() => navigate("/login")}> {/* Navigate to login page */}
          Login
        </span>
      </p>
    </div>
  );
};

// Exporting the SignupForm component to be used in other parts of the application
export default SignupForm;













